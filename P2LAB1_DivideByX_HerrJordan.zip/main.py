''' Type your code here. '''
num = int(input())
div = int(input())

num1 = num/div


num2= num1/div


num3= num2/div


#print (str(format(num1,',.0f')),str(format(num2,',.0f')),str(format(num3,',.0f')))
print(str(int(num1)), str(int(num2)), str(int(num3)))