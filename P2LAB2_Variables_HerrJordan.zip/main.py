user_int = int(input('Enter integer (32 - 126):\n'))
#print(user_int)

user_float = float(input('Enter float:\n'))
#print(user_float)

user_char = (input('Enter character:\n'))
#print(user_char)

user_string = str(input('Enter string:\n'))
#print(user_string)

# FIXME (1): Finish reading other items into variables, then output the four values on a single line separated by a space
print (user_int, user_float, user_char, user_string)
 
# FIXME (2): Output the four values in reverse
print (user_string, user_char, user_float, user_int)

# FIXME (3): Convert the integer to a characer, and output that character
to_char = chr(user_int)
print (user_int, "converted to a character is", to_char)
